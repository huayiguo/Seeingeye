#include "mbed.h"
#include "MRF24J40.h"
#include "HMC5883L.h"

#include <math.h>
#include <string>


#define SDA      p9
#define SCL      p10
#define PI       3.14159265
#define COMMAND  "G12_MA_RCD"


void send_data(char *);


const int pressureThresholdH = 99;
const int pressureThresholdL = 85;
const float shortDuration = 0.3;
const float longDuration = 2;
const float flickerAllDuration = 4;
const float flickerDuration = 0.5;
const char thisFoot = 'R';


//********** Serial port for showing RX data.
Serial pc(USBTX, USBRX);

//********** RF
// RF tranceiver to link with handheld.
MRF24J40 mrf(p11, p12, p13, p14, p21);
// Used for sending and receiving
char txBuffer[128];
char rxBuffer[128];
int rxLen;

//********** Pressure sensor
AnalogIn pressureIn(p20);
int gestureStatus = 0;

//********** Time control
Timeout gestureTimeout;

Timeout topShortTimeout;
Timeout middleShortTimeout;
Timeout topLongTimeout;
Timeout middleLongTimeout;

Timeout topFlipTimeout;
Timeout topFlipAllTimeout;
Timeout middleFlipTimeout;
Timeout middleFlipAllTimeout;

Timer refreshTimer;

//**********  LEDs you can treat these as variables (led2 = 1 will turn led2 on!)
DigitalOut middleVib(p23);
DigitalOut topVib(p24);

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);

int mockCompassFlag = 0;

//********** compass
HMC5883L hmc5883l(SDA, SCL);
float heading_tmp;
int heading;


//***************** Do not change these methods (please) *****************//

/**
* Receive data from the MRF24J40.
*
* @param data A pointer to a char array to hold the data
* @param maxLength The max amount of data to read.
*/
int rf_receive(char *data, uint8_t maxLength)
{
    uint8_t len = mrf.Receive((uint8_t *)data, maxLength);
    uint8_t header[8]= {1, 8, 0, 0xA1, 0xB2, 0xC3, 0xD4, 0x00};

    if(len > 10) {
        //Remove the header and footer of the message
        for(uint8_t i = 0; i < len-2; i++) {
            if(i<8) {
                //Make sure our header is valid first
                if(data[i] != header[i])
                    return 0;
            } else {
                data[i-8] = data[i];
            }
        }

        //pc.printf("Received: %s length:%d\r\n", data, ((int)len)-10);
    }
    return ((int)len)-10;
}

/**
* Send data to another MRF24J40.
*
* @param data The string to send
* @param maxLength The length of the data to send.
*                  If you are sending a null-terminated string you can pass strlen(data)+1
*/
void rf_send(char *data, uint8_t len)
{
    //We need to prepend the message with a valid ZigBee header
    uint8_t header[8]= {1, 8, 0, 0xA1, 0xB2, 0xC3, 0xD4, 0x00};
    uint8_t *send_buf = (uint8_t *) malloc( sizeof(uint8_t) * (len+8) );

    for(uint8_t i = 0; i < len+8; i++) {
        //prepend the 8-byte header
        send_buf[i] = (i<8) ? header[i] : data[i-8];
    }
    //pc.printf("Sent: %s\r\n", send_buf+8);

    mrf.Send(send_buf, len+8);
    free(send_buf);
}

//***************** You can start coding here *****************//

void send_data(char* str) {
    //Add to the buffer. You may want to check out sprintf
    strcpy(txBuffer, str);
    //Send the buffer
    rf_send(txBuffer, strlen(txBuffer) + 1);
    // pc.printf("Sent: %s\r\n", txBuffer);
}

void stopTopVib() {
    topVib = 1;
}

void stopMiddleVib() {
    middleVib = 1;
}

void topFlip() {
    topFlipTimeout.detach();
    topFlipTimeout.attach(&topFlip, flickerDuration);
    topVib = !topVib;
}

void middleFlip() {
    middleFlipTimeout.detach();
    middleFlipTimeout.attach(&middleFlip, flickerDuration);
    middleVib = !middleVib;
}

void stopTopFlip() {
    topFlipTimeout.detach();
    topVib = 1;
}

void stopMiddleFlip() {
    middleFlipTimeout.detach();
    middleVib = 1;
}

void resetGestureCounter() {
    gestureStatus = 0;
}

void updateGestureTimer(float delay) {
    gestureTimeout.detach();
    gestureTimeout.attach(&resetGestureCounter, delay);
}

void checkPressure() {
    float pressureV = pressureIn.read() * 100.0f;
    // pc.printf("pressure  V: %5.6f\r\n", pressureV);

    if (gestureStatus == 0 && pressureV < pressureThresholdL) {
        gestureStatus = 1;
        updateGestureTimer(0.8);
    } else if (gestureStatus == 1 && pressureV > pressureThresholdH) {
        gestureStatus = 2;
        updateGestureTimer(0.3);
    } else if (gestureStatus == 2 && pressureV < pressureThresholdL) {
        gestureStatus = 3;
        updateGestureTimer(0.5);
    } else if (gestureStatus == 3 && pressureV > pressureThresholdH) {
        gestureStatus = 4; 
        updateGestureTimer(0.3);
    } else if (gestureStatus == 4 && pressureV < pressureThresholdL) {
        gestureStatus = 5;
        updateGestureTimer(0.3);
    } else if (gestureStatus == 5) {
        gestureTimeout.detach();
        gestureStatus = 0;

        send_data(COMMAND); 
    }
}

void checkRFbuffer() {
    //Try to receive some data
    rxLen = rf_receive(rxBuffer, 128);
    if(rxLen > 0) {

        // pc.printf("Received: %s\r\n", rxBuffer);
        if (rxBuffer[4] == 'S' && (rxBuffer[5] == thisFoot || rxBuffer[5] == 'A')) {
            if (rxBuffer[7] == 'V' && rxBuffer[8] == 'B' && rxBuffer[9] == '1') {
                topShortTimeout.detach();
                topVib = 0;
                topShortTimeout.attach(&stopTopVib, shortDuration);
            } else if (rxBuffer[7] == 'V' && rxBuffer[8] == 'B' && rxBuffer[9] == '2') {
                middleShortTimeout.detach();
                middleVib = 0;
                middleShortTimeout.attach(&stopMiddleVib, shortDuration);
            } else if (rxBuffer[7] == 'V' && rxBuffer[8] == 'B' && rxBuffer[9] == '4') {
                topFlipAllTimeout.detach();
                topFlipTimeout.detach();
                topVib = 0;
                topFlipTimeout.attach(&topFlip, flickerDuration);
                topFlipAllTimeout.attach(&stopTopFlip, flickerAllDuration);
            } else if (rxBuffer[7] == 'V' && rxBuffer[8] == 'B' && rxBuffer[9] == '5') {
                middleFlipAllTimeout.detach();
                middleFlipTimeout.detach();
                middleVib = 0;
                middleFlipTimeout.attach(&middleFlip, flickerDuration);
                middleFlipAllTimeout.attach(&stopMiddleFlip, flickerAllDuration);
            } else if (rxBuffer[7] == 'V' && rxBuffer[8] == 'B' && rxBuffer[9] == '7') { // top long
                topLongTimeout.detach();
                topVib = 0;
                topLongTimeout.attach(&stopTopVib, longDuration);
            } else if (rxBuffer[7] == 'V' && rxBuffer[8] == 'B' && rxBuffer[9] == '8') { // mid long
                middleLongTimeout.detach();
                middleVib = 0;
                middleLongTimeout.attach(&stopMiddleVib, longDuration);
            }
        }
    }
}

void checkCompass(){
        float x, y, z;
        x = hmc5883l.getMx();
        y = hmc5883l.getMy();
        z = hmc5883l.getMz();
        char buffer[11];
        heading_tmp = atan2(y, z);
        if(heading_tmp < 0) 
            heading_tmp += 2*PI;
        if(heading_tmp > 2*PI) 
            heading_tmp -= 2*PI;
        
        heading_tmp = heading_tmp * 180 / PI;
        heading = (int)heading_tmp;
        heading = heading/10;
        // Correct for when signs are reversed.
        //if(heading < 0) 
        //    heading += 2*PI;
        //if(heading > 2*PI) 
        //    heading -= 2*PI;
       
        //while(heading < 0) heading += 360;
        //while(heading > 360) heading -= 360;


        // pc.printf("x: %f \t\ty: %f \t\t z: %f \t\t heading: %d \t\r\n", x, y, z, heading);
        // pc.printf("what");
        if(heading<10){
            // pc.printf("what1");
            sprintf(buffer, "G12_MA_D0%d",heading);
        }else{
             // pc.printf("what2");
            sprintf(buffer, "G12_MA_D%d",heading);
        }
       
        send_data(buffer);
        
//        wait_ms(50);
    
}


int main (void)
{
    //********** init
    pc.printf("Inicializing...\r\n");

    middleVib = 1;
    topVib = 1;

    uint8_t channel = 14;
   
    //HMC5883L *hmc5883l = new HMC5883L(SDA, SCL);

    //Set the Channel. 0 is default, 15 is max
    mrf.SetChannel(channel);

    refreshTimer.start();
  
    pc.printf("Start!\r\n");
    while(true) {
        // if (refreshTimer.read() > 2) {
        //     refreshTimer.reset();
        //     checkCompass();
        // }

        checkRFbuffer();
        checkPressure();
    }
}

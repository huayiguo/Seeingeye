#include "mbed.h"
#include "MBed_Adafruit_GPS.h"
#include "SDFileSystem.h"
#include "MRF24J40.h" // for RF module

#include <string>
#include <cmath>
#include <vector>


void recordSpotInterrupt();
void resetSpotsFun();
void checkCurrentPosition();
std::vector<float> checkBluetoothBuffer();
void send_data(char* str);
std::vector<float> getLocations();
bool isNagvigationReady();


//const int refresh_Time = 1000; //refresh time in ms
const float positionDiff = 0.001;
const float closeRange = 0.0005;
// const float farRange = 10;
const float Pi = 3.1415926535;
const char * fileLocation = "/sd/gpsInfo/customized.txt";


// SA: slave all, SL: slave left, SR: slave right
// VB1: top short, VB2: middle short, 
// VB4: top short several times, VB5: middle short several times
// VB7: top long, VB8: middle long


bool flag = false;
// bool hasGPS  = false;

//********** serial pc
Serial pc (USBTX, USBRX);

//********** GPS
Serial * gps_Serial;
Adafruit_GPS * gpsPointer;
char gps_readChar;

int gps_hour, gps_minute, gps_seconds, gps_milliseconds, gps_satellites;
int gps_day, gps_month, gps_year, gps_fix, gps_quality;
float gps_latitude, gps_longitude, gps_speed, gps_angle, gps_altitude;
char gps_lat, gps_lon;

//********** SD file
SDFileSystem sd(p5, p6, p7, p8, "sd"); 
FILE *fp;
int file_open_flag;

//********** Used for RF sending and receiving
// RF tranceiver to link with handheld.
MRF24J40 mrf(p11, p12, p13, p14, p21);

char txBuffer[128];
char rxBuffer[128];
int rxLen;

//********** bluetooth
Serial blue(p9, p10);
bool haveValidPath = false;
int num_point = 8;
//float *pathPointer;
int nextPointIdx = 0;
//std::vector<float> pathVector;

//********** mbed
InterruptIn recordSpot(p25);
InterruptIn resetSpots(p26);
DigitalOut led1(LED1);
DigitalOut led2(LED2);
Timeout vibrationLenTimeout;
Timer tt;

//********** software
float currentDirection = 0;
int turnDirection = 0;
int localCurrentDirection = 0;
int gostraightcnt = 0;
int leftCnt1 = 0;
int leftCnt2 = 0;
int rightCnt1 = 0;
int rightCnt2 = 0;
int uTurnCnt = 0;

//***************** Do not change these methods (please) *****************//

/**
* Receive data from the MRF24J40.
*
* @param data A pointer to a char array to hold the data
* @param maxLength The max amount of data to read.
*/
int rf_receive(char *data, uint8_t maxLength)
{
    uint8_t len = mrf.Receive((uint8_t *)data, maxLength);
    uint8_t header[8]= {1, 8, 0, 0xA1, 0xB2, 0xC3, 0xD4, 0x00};

    if(len > 10) {
        //Remove the header and footer of the message
        for(uint8_t i = 0; i < len-2; i++) {
            if(i<8) {
                //Make sure our header is valid first
                if(data[i] != header[i])
                    return 0;
            } else {
                data[i-8] = data[i];
            }
        }

        //pc.printf("Received: %s length:%d\r\n", data, ((int)len)-10);
    }
    return ((int)len)-10;
}

/**
* Send data to another MRF24J40.
*
* @param data The string to send
* @param maxLength The length of the data to send.
*                  If you are sending a null-terminated string you can pass strlen(data)+1
*/
void rf_send(char *data, uint8_t len)
{
    //We need to prepend the message with a valid ZigBee header
    uint8_t header[8]= {1, 8, 0, 0xA1, 0xB2, 0xC3, 0xD4, 0x00};
    uint8_t *send_buf = (uint8_t *) malloc( sizeof(uint8_t) * (len+8) );

    for(uint8_t i = 0; i < len+8; i++) {
        //prepend the 8-byte header
        send_buf[i] = (i<8) ? header[i] : data[i-8];
    }
    //pc.printf("Sent: %s\r\n", send_buf+8);

    mrf.Send(send_buf, len+8);
    free(send_buf);
}

//***************** You can start coding here *****************//


//********** init **********//

Adafruit_GPS gps_init() {
    gps_Serial = new Serial(p28,p27); //serial object for use w/ GPS
    Adafruit_GPS myGPS(gps_Serial); //object of Adafruit's GPS class
    
    myGPS.begin(9600);  //sets baud rate for GPS communication; note this may be changed via Adafruit_GPS::sendCommand(char *)
                        //a list of GPS commands is available at http://www.adafruit.com/datasheets/PMTK_A08.pdf
    
    myGPS.sendCommand(PMTK_SET_NMEA_OUTPUT_RMCGGA); //these commands are defined in MBed_Adafruit_GPS.h; a link is provided there for command creation
    myGPS.sendCommand(PMTK_SET_NMEA_UPDATE_1HZ);
    myGPS.sendCommand(PGCMD_ANTENNA);
    
    gpsPointer = &myGPS;
    return myGPS;
}

void RF_init() {
    uint8_t channel = 14;
    //Set the Channel. 0 is default, 15 is max
    mrf.SetChannel(channel);
}

void serialPC_init() {
    pc.baud(115200); //sets virtual COM serial communication to high rate; this is to allow more time to be spent on GPS retrieval
}

void interrupt_init() {
    // recordSpot.rise(&recordSpotInterrupt);
    resetSpots.rise(&resetSpotsFun);
}

Timer timer_init() {
    Timer refresh_Timer; //sets up a timer for use in loop; how often do we print GPS info?
    return refresh_Timer;
}


//********** body **********//

void resetSpotsFun() {
    if (file_open_flag == 1) {
        fclose(fp);
    }
    
    file_open_flag = 1;
    fp = fopen(fileLocation, "w");
    fprintf(fp, "");
    fclose(fp);
    file_open_flag = 0;
    
    pc.printf("All spots cleared.\r\n");
}

void recordSpotInterrupt() { 
    if (file_open_flag == 1) {
        fclose(fp);
    }
    
    file_open_flag = 1;
    fp = fopen(fileLocation, "a");

    fprintf(fp, "%5.4f %5.4f\r\n", gps_latitude, gps_longitude);
    pc.printf("Record: %5.4f %5.4f\r\n", gps_latitude, gps_longitude);

    // if (gps_fix != 1) {
    //     pc.printf("No GPS module signal.\r\n");
    // }

    // fprintf(fp, "Time: %d:%d:%d.%u\r\n", gps_hour, gps_minute, gps_seconds, gps_milliseconds);
    // pc.printf("Time: %d:%d:%d.%u\r\n", gps_hour, gps_minute, gps_seconds, gps_milliseconds);
    
    fclose(fp);
    file_open_flag = 0;
}

void print_gps_info(Adafruit_GPS myGPS) {
    pc.printf("Time: %d:%d:%d.%u\r\n", myGPS.hour, myGPS.minute, myGPS.seconds, myGPS.milliseconds);   
    pc.printf("Date: %d/%d/20%d\r\n", myGPS.day, myGPS.month, myGPS.year);
    pc.printf("Fix: %d\r\n", (int) myGPS.fix);
    pc.printf("Quality: %d\r\n", (int) myGPS.fixquality);
    if (myGPS.fix) {
        pc.printf("Location: %5.4f%c, %5.4f%c\r\n", myGPS.latitude, myGPS.lat, myGPS.longitude, myGPS.lon);
        pc.printf("Speed: %5.4f knots\r\n", myGPS.speed);
        pc.printf("Angle: %5.4f\r\n", myGPS.angle);
        pc.printf("Altitude: %5.4f\r\n", myGPS.altitude);
        pc.printf("Satellites: %d\r\n", myGPS.satellites);
    }
}

void update_holder_info(Adafruit_GPS myGPS) {
    gps_hour = myGPS.hour;
    gps_minute = myGPS.minute;
    gps_seconds = myGPS.seconds;
    gps_milliseconds = myGPS.milliseconds;
    
    gps_day = myGPS.day;
    gps_month = myGPS.month;
    gps_year = myGPS.year;
    
    gps_fix = (int) myGPS.fix;
    gps_quality = (int) myGPS.fixquality;
    
    if (myGPS.fix) {
        gps_latitude = myGPS.latitude;
        gps_lat = myGPS.lat;
        gps_longitude = myGPS.longitude;
        gps_lon = myGPS.lon;
        
        gps_speed = myGPS.speed;
        gps_angle = myGPS.angle;
        gps_altitude = myGPS.altitude;
        gps_satellites = myGPS.satellites;
    }
}

int checkCurrentPosition(float y, float x) {
    // pc.printf("current: %5.4f %5.4f; %5.4f %5.4f\r\n", gps_latitude, gps_longitude, y, x);
    y = -y;
    if (y - gps_latitude < positionDiff && y - gps_latitude > -positionDiff) {
        if (x - gps_longitude < positionDiff && x - gps_longitude > -positionDiff) {
            // pc.printf("in file: %5.4f %5.4f\r\n", y, x);
            // pc.printf("current: %5.4f %5.4f\r\n", gps_latitude, gps_longitude);
            return 1;
        }
    }
    return 0;
}

void checkAllSpots() {
    // pc.printf("checkAllSpots\r\n");
    if (file_open_flag == 1) {
        fclose(fp);
    }
    
    file_open_flag = 1;
    fp = fopen(fileLocation, "r");
    char buff[255];
    float x_c, y_c;
    
    while(getc(fp) != EOF) {
        fscanf(fp, "%s", buff);
        y_c = atof(buff); // latitude
        fscanf(fp, "%s", buff);
        x_c = atof(buff); // longitude
        int danger = checkCurrentPosition(y_c, x_c);
        if (danger == 1) {
            send_data("G12_SA_VB7");
            send_data("G12_SA_VB8"); 
            break;
        }
    }
    
    fclose(fp);
    file_open_flag = 0;
}

std::vector<float> checkBluetoothBuffer() {
    // pc.printf("check bluetooth\n");
    if (blue.readable()) 
    {
        if(isNagvigationReady()){
            std::vector<float> test;
            test = getLocations();
            // pathPointer = (float *)malloc(sizeof(float)*num_point*2);
            
            pc.printf("Navigation is Ready.\r\n");

            //print result
            //  int i = 0;
            //  pc.printf("number of point: %d\n", num_point);
            //   for(i=0;i<num_point*2;i++){
            //  memcpy(tmp+(i*4),pathPointer+(i*4),4);
            //  pc.printf("%f ",pathPointer[i]);
            //  i++;
            //  memcpy(tmp+(i*4),pathPointer+(i*4),4);
            //   pc.printf("%f \r\n",pathPointer[i]);
            //  }
            pc.printf("finish \r\n");
            return test;
        }else{
            //  pc.printf("bluetooth not avaialable\n");    
        }
    }
    //  pc.printf("check bluetooth done\n");
    std::vector<float> testno;
    return testno;
}

void send_data(char* str) {
    //Add to the buffer. You may want to check out sprintf
    strcpy(txBuffer, str);
    //Send the buffer
    rf_send(txBuffer, strlen(txBuffer) + 1);
    pc.printf("Sent: %s\r\n", txBuffer);
}

int compassDirectionCompute(int highBit, int lowBit, int shift) {
    int tmp = highBit * 100 + lowBit * 10 + shift;
    if (tmp >= 360) {
        tmp -= 360;
    } else if (tmp < 0) {
        tmp += 360;
    }
    return tmp;
}

void checkRFbuffer() {
    //pc.printf("Enter checkRFbuffer \r\n");
    //Try to receive some data
    rxLen = rf_receive(rxBuffer, 128);
    
    if(rxLen > 0) {
        pc.printf("Received: %s\r\n", rxBuffer);
        if (rxBuffer[4] == 'M' && rxBuffer[5] == 'A') {
            if (rxBuffer[7] == 'R' && rxBuffer[8] == 'C' && rxBuffer[9] == 'D') { // record dangerous spot
                recordSpotInterrupt();
            } else if (rxBuffer[7] == 'D') { // receive a direction from slave
                int highBit = (int)rxBuffer[8] - 48;
                int lowBit = (int)rxBuffer[9] - 48;
                localCurrentDirection = compassDirectionCompute(highBit, lowBit, 0);

                // pc.printf("update current direction: %d\r\n", localCurrentDirection);
                // pc.printf("%s",rxBuffer);
            } else if (rxBuffer[7] == 'C' && rxBuffer[8] == 'A' && rxBuffer[9] == 'L'){
                haveValidPath = false;
                nextPointIdx = 0;
            }
        }
    }
   
}

float distance(float x1, float y1, float x2, float y2) {
    float dist =  sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    return dist;
}

void checkDirection(std::vector<float>  pathVector) {
   
    float next_x = pathVector[nextPointIdx+1];
    float next_y = pathVector[nextPointIdx];
    
    float target_x = next_x - gps_latitude;
    float target_y = -(next_y - gps_longitude);
            
    float target_ang = atan2((float)target_y, (float)target_x) * (180/Pi);
    if (target_ang < 0) {
        target_ang += 360;
    }

    int ang_diff = (int)target_ang - localCurrentDirection;
    if (ang_diff < 0) {
        ang_diff += 360;
    }

    float dist = distance(next_x, next_y, gps_latitude, gps_longitude);
    if(!flag){
         pc.printf("(lan, lon) next: %5.4f  %5.4f current: %5.4f  %5.4f diff: %5.4f %5.4f %d\r\n",next_x, next_y, gps_latitude, gps_longitude, target_x, target_y, nextPointIdx);
         pc.printf("dist is  %f \r\n",dist);
         pc.printf("target_ang: %f \r\n", target_ang);
         flag = true;
    }
   
    //continue walking
    if((dist > closeRange)){
        if (ang_diff <= 30 || ang_diff > 330) { // go straight
            if(gostraightcnt >= 30000){
                send_data("G12_SA_VB1");
                gostraightcnt = 0;    
            }
        } else if (ang_diff > 30 && ang_diff <= 90) { // turn right
            if(rightCnt1 >= 30000){
                send_data("G12_SR_VB1");
                rightCnt1=0;
            }
        } else if (ang_diff > 90 && ang_diff <= 135) { // turn right
             if(rightCnt2 >= 30000){
                send_data("G12_SR_VB2");
                rightCnt2=0; 
            }
        } else if (ang_diff > 135 && ang_diff <= 225) { // u turn
            if (uTurnCnt >= 30000) {
                send_data("G12_SA_VB2");
                uTurnCnt=0;
            }
        } else if (ang_diff > 225 && ang_diff <= 270) { // turn left
            if(leftCnt2 >= 30000){
                send_data("G12_SL_VB2");
                leftCnt2=0;
            }
        } else if (ang_diff > 270 && ang_diff <= 330) { // turn left
             if(leftCnt1 >= 30000){
                send_data("G12_SL_VB1");
                leftCnt1=0; 
            }
        }

    // reach the point    
    }else if( (dist < closeRange)){
        if(nextPointIdx == num_point * 2 - 2){
            // stop
            send_data("G12_SA_VB4");
            send_data("G12_SA_VB5");
        }else{
            nextPointIdx += 2;
            flag = false;
            pc.printf("Hit spot: %5.2f%c, %5.2f%c\n", gpsPointer->latitude, gpsPointer->lat, gpsPointer->longitude, gpsPointer->lon);
        }
    }
    
}

void getGPSfromBlue(bool flags){
    
     int j = 0;
     char holder[11];
     memset(holder, 0, 11);
    // pc.printf("checking\n");
    if(!flags){
        // pc.printf("checking2\n");
        if(blue.readable()){
            // pc.printf("checking3\n");
            char a = blue.getc();
            if(a=='0'){
                // pc.printf("get ");
            } else {
                pc.putc(a);
                // pc.printf("checking4\n");
                return;
            }
        }else{
            // pc.printf("checking5\n");
            return;    
        }
    }
   
   /*sync again*/
   while(true){
        if(blue.readable()){
            char a = blue.getc();
            if(a=='9')break;
            else pc.putc(a);
         }
   }

    /*GPS info*/
    for(j=0;j<11;j++){
        holder[j] = blue.getc();
    }

    pc.printf("GPS: %s  ", holder);
    gps_longitude = atof(holder);
    // blue.scanf("%s",&holder);
    memset(holder, 0, 11);
    for(j=0;j<11;j++){
        holder[j] = blue.getc();
    }
    pc.printf("%s \n", holder);
    
    gps_latitude = atof(holder);
    //result[i]= atof(holder);
    //pathVector.push_back(atof(holder));
    flag = false;    
}

std::vector<float> getLocations(){
     //number of latlng to be recevice 
     num_point = 8;
     int i = 0;
     int j = 0;
     char holder[11];
     char buffer[3];
     // pc.printf("Bluetooth connection step1.\r\n");
  
     std::vector<float> pathVector;
     //sync
     
     while(true){
         if(blue.readable()){
             char a = blue.getc();
             if(a=='*')break;
             else if(a=='0'){
                return pathVector;  
             }
             else pc.putc(a);
         }
     }

     //get num points 
     // pc.printf("Bluetooth connection step2.\r\n");
      while(true){
         if(blue.readable()){
             for(int j=0;j<3;j++){
                 char a = blue.getc();
                 buffer[j]=a;
                 pc.putc(a);
             }      
             num_point = atoi(buffer);
             //pc.printf("buffer is %d",buffer);
             pc.printf("Number of point:  %d\r\n",num_point);   
             break;
         }
      }
    
     //float result[num_point*2];
     // pc.printf("  %d\r\n",num_point);

     //sync again
     // pc.printf("Bluetooth connection step3.\r\n");
     while(true){
         if(blue.readable()){
             char a = blue.getc();
             if(a=='*')break;
             else pc.putc(a);
         }
     }
     
     // pc.printf("Bluetooth connection step4.\r\n");
     while(i<num_point*2){
        if(blue.readable()){
            
            for(j=0;j<11;j++){
                holder[j] = blue.getc();
            }
            // blue.scanf("%s",&holder);
            // result[i]= atof(holder);
           
            pathVector.push_back(atof(holder));
            i++;
             pc.printf("Iteration %d, %d: %s  ", i, i+ 1, holder);
            // blue.scanf("%s",&holder);
            for(j=0;j<11;j++){
                holder[j] = blue.getc();
            }
            //result[i]= atof(holder);
            pathVector.push_back(atof(holder));
            i++;
            pc.printf("%s\r\n", holder);
           
        } 
     }
     // pc.printf("size of pathVector is %d \r\n", pathVector.size());
     // pc.printf("Bluetooth connection step5.\r\n");
     haveValidPath = true;
     return pathVector;    
}

bool isNagvigationReady(){
    char a = blue.getc();
    if(a=='*'){
        return true;
    }else if(a=='0'){
        getGPSfromBlue(true);  
        return false; 
    }
    else return false;
}

int main() {
    //********** init
    Adafruit_GPS myGPS = gps_init();
    Timer refresh_Timer = timer_init();
    RF_init();
    serialPC_init();
    interrupt_init();
    blue.baud(9600);
    nextPointIdx = 0;
    std::vector<float> pathVectors;
    pc.printf("Master initialization completed.\r\n");
    send_data("G12_SA_VB2");

    //********** prepare before main loop    
    // wait(1);
    resetSpotsFun();
    refresh_Timer.start();  //starts the clock on the timer
    
    while(true){
      
        getGPSfromBlue(false);
   
        //********** check RF information
        checkRFbuffer();
       
        //********** check path information
        if (!haveValidPath) {
            // pc.printf("checkinghere");
            pathVectors = checkBluetoothBuffer();
            // pc.printf("4 %5.4f  %5.4f  size of vector %d\r\n",pathVectors[0], pathVectors[1], pathVectors.size());
        } else {
            checkDirection(pathVectors);
        }
        
        if (refresh_Timer.read() > 1) {
            refresh_Timer.reset();
            checkAllSpots();
        }

        gostraightcnt++;
        leftCnt1++;
        leftCnt2++;
        rightCnt1++;
        rightCnt2++;
        uTurnCnt++;
    }
}